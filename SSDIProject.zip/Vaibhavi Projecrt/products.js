const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the product schema
const productSchema = new Schema({
    productName: {
        type: String,
        required: true
    },
    productPrice: {
        type: Number,
        required: true
    },
    productQuantity: {
        type: Number,
        required: true
    },
    vendorName: {
        type: String,
        required: true
    },
    vendorEmail: {
        type: String,
        required: true
    },
    warehouse: {
        type: String,
        required: true
    },
    status: {
        type: String,
        required: true,
        enum : ["Completed", "Pending", "Approved"]
    },
});

// Create a model using the schema
const Product = mongoose.model('productsinfo', productSchema);

module.exports = Product;
