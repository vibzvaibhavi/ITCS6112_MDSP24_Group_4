const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const port = 3000; // You can change this port number if needed
const mongoose = require("mongoose");
const User = require("./userModel");
const Product = require("./products.js");
const Warehouse = require("./Warehouse.js")

mongoose
  .connect("mongodb://localhost:27017/Warehouse-Managment", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB", err));

  function addWarehouse(warehouse) {
    // Check if a warehouse with the same name already exists
    Warehouse.findOne({ name : warehouse })
      .then(existingWarehouse => {
        if (existingWarehouse) {
          console.log(`Warehouse with name '${warehouse}' already exists.`);
          return;
        }
        console.log(warehouse);
        console.log(existingWarehouse);
  
        // Create a new warehouse document
        const newWarehouse = new Warehouse({ name : warehouse });
  
        // Save the new warehouse document
        newWarehouse.save()
          .then(() => {
            console.log(`Warehouse with name '${warehouse}' added successfully.`);
          })
          .catch(error => {
            console.error('Error adding warehouse:', error);
          });
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }

app.use(express.static("templates"));
app.use(cookieParser());
app.set("views", "./templates");
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use((req, res, next) => {
  console.log(req.url);
  if (req.url === "/userLogin") {
    next();
  } else if (req.cookies.userData) {
    next();
  } else {
    res.clearCookie("userData");
    res.redirect("/userLogin");
  }
});

app.get("/userLogin", (req, res) => {
  res.render("userLogin", { title: "Manager Login page" });
});

app.get("/outOfStockProducts", async (req, res) => {
  try {
    const outOfStockProducts = await Product.find({ $or: [{ status: 'Pending' }, { status: 'Approved' }], productQuantity: { $lt: 60 } });
    console.log(outOfStockProducts);
    res.json(outOfStockProducts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/warehouses", (req, res) => {
  // Find all warehouses
  Warehouse.find({})
    .then(warehouses => {
      // Send the list of warehouses as a JSON response
      res.json(warehouses);
    })
    .catch(error => {
      // If there's an error, send a 500 status code with an error message
      res.status(500).json({ error: 'Internal server error' });
    });
});

app.get("/products", async (req, res) => {
  const city = req.query.warehouse;
  const products = await Product.find({ warehouse: city });
  res.json(products);
});

app.post("/userLogin", async (req, res) => {
  var username = req.body["username"];
  var password = req.body["password"];
  const user = await User.findOne({ username: username, password: password });

  if (user) {
    const userObject = { username: username, role: user.role, name : user.name};
    res.cookie("userData", JSON.stringify(userObject));
    if(user.role==="manager"){
      res.status(200).redirect("/manager/home");
    }
    else if (user.role=="vendor"){
      res.status(200).redirect("/vendor/home");
    }
  } else {
    res.status(401).json({ message: "Invalid username or password" });
  }
});

app.get("/manager/home", (req, res) => {
  res.render("./manager/managerHome");
});

app.get("/manager/searchProducts", (req, res) => {
  res.render("./manager/managerSearchProducts");
});
app.post("/manager/searchProducts", async (req, res) => {
  const productName = req.body.productName;
  const products = await Product.find(
    {
      productName: { $regex: productName, $options: "i" },
    },
    { _id: 0 }
  );
  console.log("Products found:", products);
  res.send(products);
});

app.get("/manager/addProduct", (req, res) => {
  res.render("./manager/managerAddProducts", { message: "" });
});
app.post("/manager/addProduct", async (req, res) => {
  try {
    const productName = req.body.productName;

    // Check if product with the same name already exists
    const existingProduct = await Product.findOne({ productName });

    if (existingProduct) {
      console.log(`Product with name '${productName}' already exists.`);
      return res.status(400).render("./manager/managerAddProducts", {
        message: "Product already exists",
      });
    }

    // If product doesn't exist, proceed to add it
    const productPrice = req.body.productPrice;
    const productQuantity = req.body.productQuantity;
    const vendorName = req.body.vendorName;
    const vendorEmail = req.body.vendorEmail;
    const warehouse = req.body.warehouse;
    const status = "Completed";

    addWarehouse(warehouse);

    const newProduct = new Product({
      productName,
      productPrice,
      productQuantity,
      vendorName,
      vendorEmail,
      warehouse,
      status
    });

    // Save the new product to the database
    const savedProduct = await newProduct.save();

    console.log("Product saved successfully:", savedProduct);
    res.status(201).render("./manager/managerAddProducts", {
      message: "Added Product Successfully",
    });
  } catch (err) {
    console.error("Error saving product:", err);
    // Respond with error status and message
    res.status(500).render("./manager/managerAddProducts", {
      message: "Failed to add Product",
    });
  }
});


app.get("/manager/updateProduct", (req, res) => {
  res.render("./manager/managerUpdateProduct", { message: "" });
});
app.post("/manager/updateProduct", async (req, res) => {
  const {
    productName,
    productPrice,
    productQuantity,
    vendorName,
    vendorEmail,
    warehouse,
  } = req.body;
  addWarehouse(warehouse);
  try {
    const updatedProduct = await Product.findOneAndUpdate(
      { productName: productName }, // Condition to find the product
      {
        productName,
        productPrice,
        productQuantity,
        vendorName,
        vendorEmail,
        warehouse,
      },
      { new: true }
    );
    
    if (!updatedProduct) {
      return res.status(404).render("./manager/managerUpdateProduct", { message: "Product not found" });
    }
    console.log("Product updated successfully:", updatedProduct);
    res.status(200).render("./manager/managerUpdateProduct", {
      message: "Updated Product Successfully",
    });
  } catch (err) {
    console.error("Error updating product:", err);
    return res.status(404).render("./manager/managerUpdateProduct", { message: "Product not found" });
  }
});
app.get("/manager/outOfStock", (req, res) => {
  res.render("./manager/managerOutOfStock", { message: "" });
});




// Vendor routes

app.get("/vendor/home", (req, res) => {
  res.render("./vendor/vendorHome");
});

app.get("/vendor/getProducts", async (req, res) => {
  try {
    const vendorName = JSON.parse(req.cookies.userData)["name"];
    const products = await Product.find({ status: "Pending", vendorName: vendorName });
    console.log(products,vendorName)
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/vendor/updateProduct", async (req, res)=>{
  try {
    // Extract the product name from the request body
    const productName = req.body.productName;

    // Update the status of the product to "Approved"
    const updatedProduct = await Product.findOneAndUpdate(
      { productName: productName },
      { status: "Approved" },
      { new: true }
    );

    // If the product is successfully updated, respond with a success message
    if (updatedProduct) {
      res.status(200).json({ message: "Product updated successfully" });
    } else {
      // If the product is not found, respond with an error message
      res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    // If an error occurs, respond with an error message
    res.status(500).json({ message: "Failed to update product", error: error.message });
  }
})








app.get("/userLogOut", (req, res) => {
  res.clearCookie("userData");
  res.redirect("/userLogin");
});


// Start the server
app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
