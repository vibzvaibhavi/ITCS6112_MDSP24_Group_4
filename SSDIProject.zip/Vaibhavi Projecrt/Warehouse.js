const mongoose = require('mongoose');

// Define Warehouse schema
const warehouseSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  }
});

// Create Warehouse model
const Warehouse = mongoose.model('Warehouse', warehouseSchema);

module.exports = Warehouse;
