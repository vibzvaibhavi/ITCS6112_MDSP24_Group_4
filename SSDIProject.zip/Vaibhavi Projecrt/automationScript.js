const mongoose = require('mongoose');
const Product = require('./products');
const Warehouse = require('./Warehouse');
const User = require('./userModel');
// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Warehouse-Managment', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
    const sampleProducts = [
      {
        productName: 'Sample Product 1',
        productPrice: 10.99,
        productQuantity: 100,
        vendorName: 'Vendor 1',
        vendorEmail: 'vendor1@example.com',
        warehouse: 'Warehouse A',
        status: 'Completed'
      },
      {
        productName: 'Sample Product 2',
        productPrice: 15.99,
        productQuantity: 50,
        vendorName: 'Vendor 2',
        vendorEmail: 'vendor2@example.com',
        warehouse: 'Warehouse B',
        status: 'Completed'
      },
      {
      productName: 'Sample Product 3',
      productPrice: 10.99,
      productQuantity: 100,
      vendorName: 'Vendor 1',
      vendorEmail: 'vendor1@example.com',
      warehouse: 'Warehouse A',
      status: 'Pending'
    },
    {
      productName: 'Sample Product 4',
      productPrice: 15.99,
      productQuantity: 50,
      vendorName: 'Vendor 2',
      vendorEmail: 'vendor2@example.com',
      warehouse: 'Warehouse B',
      status: 'Pending'
    },
    {
      productName: 'Sample Product 5',
      productPrice: 15.99,
      productQuantity: 50,
      vendorName: 'Vendor 1',
      vendorEmail: 'vendor2@example.com',
      warehouse: 'Warehouse A',
      status: 'Completed'
    },
      // Add more sample products as needed
    ];

    // Insert sample products into the database
    Product.insertMany(sampleProducts)
      .then(() => {
        console.log('Sample products inserted successfully');
        // Disconnect from MongoDB after insertion
        mongoose.disconnect();
      })
      .catch(err => {
        console.error('Error inserting sample products:', err);
        // Disconnect from MongoDB on error
        mongoose.disconnect();
      });

    const sampleWarehouses = [
      {name : 'Warehouse A'},
      {name : 'Warehouse B'}
    ]
    Warehouse.insertMany(sampleWarehouses)
      .then(() => {
        console.log('Sample Warehouses inserted successfully');
        // Disconnect from MongoDB after insertion
        mongoose.disconnect();
      })
      .catch(err => {
        console.error('Error inserting sample Warehouses:', err);
        // Disconnect from MongoDB on error
        mongoose.disconnect();
      });

      const sampleUsers = [
        {
          name : "manager",
          username : "manager",
          password : "12345",
          role : "manager"
        },
        {
          name : "Vendor 1",
          username : "vendor1",
          password : "12345",
          role : "vendor"
        },
        {
          name : "Vendor 2",
          username : "vendor2",
          password : "12345",
          role : "vendor"
        },
      ]
      User.insertMany(sampleUsers)
        .then(() => {
          console.log('Sample Users inserted successfully');
          // Disconnect from MongoDB after insertion
          mongoose.disconnect();
        })
        .catch(err => {
          console.error('Error inserting sample Users:', err);
          // Disconnect from MongoDB on error
          mongoose.disconnect();
        });
  })
  .catch(err => console.error('Error connecting to MongoDB:', err));
