const mongoose = require('mongoose');

// Define schema for existing collection
const existingCollectionSchema = new mongoose.Schema({
  // Define schema fields here
  // For example:
  name : String,
  username: String,
  password: Number,
  role: String
});

// Create model for existing collection
const ExistingCollection = mongoose.model('UserProfiles', existingCollectionSchema);

module.exports = ExistingCollection;
