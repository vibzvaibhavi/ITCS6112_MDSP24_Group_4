const mongoose = require('mongoose');
const cron = require('node-cron');
const Product = require('./products'); // Import your Product model

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/your_database', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('Connected to MongoDB');
  
  // Schedule the task to run every 4 hours
  cron.schedule('0 */4 * * *', async () => {
    try {
      console.log('Running task to update product statuses...');
      // Query all products from the database
      const products = await Product.find();
      
      // Loop through each product
      for (const product of products) {
        // Check if quantity is less than 60 and status is not already "Approved"
        if (product.productQuantity < 60 && product.status !== 'Approved') {
          // Update status to "Pending"
          const updatedProduct = await Product.findByIdAndUpdate(product._id, { status: 'Pending' });
          console.log(`Product "${updatedProduct.productName}" status updated to Pending`);
        }
      }
    } catch (error) {
      console.error(`Error occurred while updating product statuses: ${error.message}`);
    }
  });
})
.catch(error => {
  console.error(`Failed to connect to MongoDB: ${error.message}`);
});
